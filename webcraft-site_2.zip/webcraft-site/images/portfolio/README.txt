PORTFOLIO / PORTOFOLIU
======================
The portfolio shows the 9 concept sites in /portfolio/ as LIVE pages (real iframes,
not screenshots). Keep the /portfolio/ folder next to index.html when you upload.

To add a real client project later, either:
  • add its page to /portfolio/ and add an entry with  page: 'portfolio/name.html'
  • or drop a screenshot here (1600 x 1000 px) and add an entry with
    img: 'images/portfolio/name.jpg'
Edit the PORTFOLIO list near the top of the <script> in index.html.

---
Portofoliul afișează cele 9 site-uri concept din /portfolio/ LIVE (nu capturi).
Încarcă folderul /portfolio/ împreună cu index.html. Pentru proiecte noi, editează
lista PORTFOLIO din index.html (page: ... sau img: ...).
